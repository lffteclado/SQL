if exists(select 1 from sysobjects where name = 'whRelFTVendasDescontos')
begin  drop proc dbo.whRelFTVendasDescontos	end
go

create proc dbo.whRelFTVendasDescontos
/*INICIO_CABEC_PROC
-----------------------------------------------------------------------------------------------
 Empresa......: T-Systems
 Projeto......: DealerStarPlus / Faturamento
 Analista.....: Alex Sandro Ribeiro
 Procedure....: whRelFTVendasDescontos
 Utilizada em.: relFTVendasDescontos - Rela��o de vendas com desconto

 ---Data--- -----Respons�vel----- -----Descricao-----
 11/03/2004 Alex Sandro Ribeiro   Desenvolvimento inicial
 18/10/2005 Marcio Schvartz	  Incluido Devolucoes de Venda no total do relatorio
 15/02/2006 Marcio Schvartz	  Filtrado Devolu��es de Venda por vendedor com relacionamento
				  na tbRepresentantePedido porque tabelas do documento 
				  (tbComissaoDocumento ou tbDoctoReceberRepresentante) nao existem 
-----------------------------------------------------------------------------------------------
 exec dbo.whRelFTVendasDescontos 	@CodigoEmpresa=1608,
					@CodigoLocal=0,
					@DataInicial='2009-01-01',
					@DataFinal='2009-12-31',
					@ClienteInicial=2,
					@ClienteFinal=99999999999999,
					@CCustoInicial=0,
					@PlanoPagtoInicial='',
					@PlanoPagtoFinal='ZZZZ',
					@CCustoFinal=99999999,
					@RepresentanteInicial=0,
					@RepresentanteFinal=9999,
					@PEC='F',
					@CLO='F',
					@MOB='F',
					@VEC='V',
					@OUT='F',
					@ComDesconto='V',
					@SemDesconto='V',
					@SomenteClientePrimeiraCompra = 'V'

dbo.whRelFTVendasDescontos 1608,0,'2010-08-01','2010-08-30',1,99999999999999,0,99999,'','ZZZZ',0,9999,'V','V','V','V','V','V','V','F'
-----------------------------------------------------------------------------------------------
FIM_CABEC_PROC*/

	@CodigoEmpresa					dtInteiro04,
	@CodigoLocal					dtInteiro04,
	@DataInicial					char(10),
	@DataFinal						char(10),
	@ClienteInicial					numeric(14),
	@ClienteFinal					numeric(14),
	@CCustoInicial					numeric(8),
	@CCustoFinal					numeric(8),
	@PlanoPagtoInicial				varchar(4),
	@PlanoPagtoFinal				varchar(4),
	@RepresentanteInicial			numeric(6),
	@RepresentanteFinal				numeric(6),
	@PEC							char(1),
	@CLO							char(1),
	@MOB							char(1),
	@VEC							char(1),
	@OUT							char(1),
	@ComDesconto					char(1),
	@SemDesconto					char(1),
	@SomenteClientePrimeiraCompra	char(1)

WITH ENCRYPTION
AS

SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED


	----------------------------------------------------------------------
	-- Vendas
	----------------------------------------------------------------------
	select 	 doc.CodigoEmpresa		as CodigoEmpresa
		,doc.CodigoLocal			as CodigoLocal
		,0 							as TipoTotalizacao
		,doc.DataDocumento			as DataDocumento
		,doc.NumeroDocumento		as NumeroDocumento
		,doc.CodigoCliFor			as CodigoCliFor
		,dft.CentroCusto			as CentroCusto
		,dft.CodigoPlanoPagamento	as CodigoPlanoPagamento
		,doc.ValorContabilDocumento	as ValorContabilDocumento
		,dft.OrigemDocumentoFT		as OrigemDocumentoFT
		
		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'PEC') > 0
			then	'V'
			else	'F'
		end			as TipoPEC

		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'CLO') > 0
			then	'V'
			else	'F'
		end			as TipoCLO

		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'MOB') > 0
			then	'V'
			else	'F'
		end			as TipoMOB

		,case	when	dft.OrigemDocumentoFT = 'CV'
			then	'V'
			else	'F'
		end			as TipoVEC

		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'OUT') > 0
			then	'V'
			else	'F'
		end			as TipoOUT

		,(select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))

		 from	tbItemDocumento idoc 
		 inner 	join tbItemDocumentoFT idft 
		 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
		 and	idft.CodigoLocal		 = idoc.CodigoLocal
		 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
		 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
		 and	idft.DataDocumento		 = idoc.DataDocumento
		 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
		 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
		 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

		 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
		 and	idoc.CodigoLocal		 = doc.CodigoLocal
		 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
		 and	idoc.DataDocumento		 = doc.DataDocumento
		 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
		 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
		 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao) as ValorDesconto

		,case when @PEC = 'V' then
			 (select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'PEC'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorDescontoPeca

		,case when @CLO = 'V' then
			(select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))

			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento
	
			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'CLO'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end as ValorDescontoCLO
		
		,case when @MOB = 'V' then
			(select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))

			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and		idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento
	
			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'MOB'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end as ValorDescontoMOB

		,case when @VEC = 'V' then
			 (select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'VEC'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorDescontoVEC

		,case when @OUT = 'V' then
			 (select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'OUT'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorDescontoOUT

		,case when @PEC = 'V' then
			 (select sum(coalesce(idoc2.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc2 
			 inner 	join tbItemDocumentoFT idft2 
			 on	idft2.CodigoEmpresa		 = idoc2.CodigoEmpresa
			 and	idft2.CodigoLocal		 = idoc2.CodigoLocal
			 and	idft2.EntradaSaidaDocumento	 = idoc2.EntradaSaidaDocumento
			 and	idft2.CodigoCliFor		 = idoc2.CodigoCliFor
			 and	idft2.DataDocumento		 = idoc2.DataDocumento
			 and	idft2.NumeroDocumento		 = idoc2.NumeroDocumento
			 and	idft2.TipoLancamentoMovimentacao  = idoc2.TipoLancamentoMovimentacao
			 and	idft2.SequenciaItemDocumento	 = idoc2.SequenciaItemDocumento

			 where	idoc2.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc2.CodigoLocal		 = doc.CodigoLocal
			 and	idoc2.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc2.DataDocumento		 = doc.DataDocumento
			 and	idoc2.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc2.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc2.TipoRegistroItemDocto  = 'PEC'
			 and	idoc2.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilPeca

		,case when @CLO = 'V' then
			 (select sum(coalesce(idoc2.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc2 
			 inner 	join tbItemDocumentoFT idft2 
			 on	idft2.CodigoEmpresa		 = idoc2.CodigoEmpresa
			 and	idft2.CodigoLocal		 = idoc2.CodigoLocal
			 and	idft2.EntradaSaidaDocumento	 = idoc2.EntradaSaidaDocumento
			 and	idft2.CodigoCliFor		 = idoc2.CodigoCliFor
			 and	idft2.DataDocumento		 = idoc2.DataDocumento
			 and	idft2.NumeroDocumento		 = idoc2.NumeroDocumento
			 and	idft2.TipoLancamentoMovimentacao  = idoc2.TipoLancamentoMovimentacao
			 and	idft2.SequenciaItemDocumento	 = idoc2.SequenciaItemDocumento

			 where	idoc2.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc2.CodigoLocal		 = doc.CodigoLocal
			 and	idoc2.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc2.DataDocumento		 = doc.DataDocumento
			 and	idoc2.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc2.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc2.TipoRegistroItemDocto  = 'CLO'
			 and	idoc2.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilCLO

		,case when @MOB = 'V' then
			 (select sum(coalesce(idoc2.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc2 
			 inner 	join tbItemDocumentoFT idft2 
			 on	idft2.CodigoEmpresa		 = idoc2.CodigoEmpresa
			 and	idft2.CodigoLocal		 = idoc2.CodigoLocal
			 and	idft2.EntradaSaidaDocumento	 = idoc2.EntradaSaidaDocumento
			 and	idft2.CodigoCliFor		 = idoc2.CodigoCliFor
			 and	idft2.DataDocumento		 = idoc2.DataDocumento
			 and	idft2.NumeroDocumento		 = idoc2.NumeroDocumento
			 and	idft2.TipoLancamentoMovimentacao  = idoc2.TipoLancamentoMovimentacao
			 and	idft2.SequenciaItemDocumento	 = idoc2.SequenciaItemDocumento

			 where	idoc2.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc2.CodigoLocal		 = doc.CodigoLocal
			 and	idoc2.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc2.DataDocumento		 = doc.DataDocumento
			 and	idoc2.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc2.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc2.TipoRegistroItemDocto  = 'MOB'
			 and	idoc2.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilMOB

		,case when @VEC = 'V' then
			 (select sum(coalesce(idoc2.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc2 
			 inner 	join tbItemDocumentoFT idft2 
			 on	idft2.CodigoEmpresa		 = idoc2.CodigoEmpresa
			 and	idft2.CodigoLocal		 = idoc2.CodigoLocal
			 and	idft2.EntradaSaidaDocumento	 = idoc2.EntradaSaidaDocumento
			 and	idft2.CodigoCliFor		 = idoc2.CodigoCliFor
			 and	idft2.DataDocumento		 = idoc2.DataDocumento
			 and	idft2.NumeroDocumento		 = idoc2.NumeroDocumento
			 and	idft2.TipoLancamentoMovimentacao  = idoc2.TipoLancamentoMovimentacao
			 and	idft2.SequenciaItemDocumento	 = idoc2.SequenciaItemDocumento

			 where	idoc2.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc2.CodigoLocal		 = doc.CodigoLocal
			 and	idoc2.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc2.DataDocumento		 = doc.DataDocumento
			 and	idoc2.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc2.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc2.TipoRegistroItemDocto  = 'VEC'
			 and	idoc2.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilVEC

		,case when @OUT = 'V' then
			 (select sum(coalesce(idoc2.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc2 
			 inner 	join tbItemDocumentoFT idft2 
			 on	idft2.CodigoEmpresa		 = idoc2.CodigoEmpresa
			 and	idft2.CodigoLocal		 = idoc2.CodigoLocal
			 and	idft2.EntradaSaidaDocumento	 = idoc2.EntradaSaidaDocumento
			 and	idft2.CodigoCliFor		 = idoc2.CodigoCliFor
			 and	idft2.DataDocumento		 = idoc2.DataDocumento
			 and	idft2.NumeroDocumento		 = idoc2.NumeroDocumento
			 and	idft2.TipoLancamentoMovimentacao  = idoc2.TipoLancamentoMovimentacao
			 and	idft2.SequenciaItemDocumento	 = idoc2.SequenciaItemDocumento

			 where	idoc2.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc2.CodigoLocal		 = doc.CodigoLocal
			 and	idoc2.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc2.DataDocumento		 = doc.DataDocumento
			 and	idoc2.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc2.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc2.TipoRegistroItemDocto  = 'OUT'
			 and	idoc2.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilOUT

	into	#tmpVendasDescontos

	from 	tbDocumento 			doc 

	inner	join tbDocumentoFT 		dft 
	on	dft.CodigoEmpresa		= doc.CodigoEmpresa
 	and	dft.CodigoLocal			= doc.CodigoLocal
 	and	dft.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
 	and	dft.DataDocumento		= doc.DataDocumento
 	and	dft.CodigoCliFor		= doc.CodigoCliFor
 	and	dft.NumeroDocumento		= doc.NumeroDocumento
	and	dft.TipoLancamentoMovimentacao  = 7
 	and	dft.CentroCusto			between @CCustoInicial and @CCustoFinal
 	and    ((dft.CodigoPlanoPagamento is null)
 		or (dft.CodigoPlanoPagamento between @PlanoPagtoInicial and @PlanoPagtoFinal))

 	-------------------------------------------- selecao dos parametros recebidos
 	where	doc.CodigoEmpresa		= @CodigoEmpresa
 	and	doc.CodigoLocal			= @CodigoLocal
 	and	doc.DataDocumento 		between @DataInicial 	and @DataFinal
 	and	doc.CodigoCliFor		between @ClienteInicial and @ClienteFinal
 	and	doc.EntradaSaidaDocumento	= 'S'
 	and	doc.CondicaoNFCancelada		= 'F'
 	and	doc.TipoLancamentoMovimentacao  in (7,11)

	------------------------------------------- selecao do range de representante
	and	((dft.OrigemDocumentoFT = 'CV')

	or	exists(select * from tbComissaoDocumento rep 
			where	rep.CodigoEmpresa		= doc.CodigoEmpresa
			and	rep.CodigoLocal			= doc.CodigoLocal
			and	rep.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
			and	rep.DataDocumento		= doc.DataDocumento
			and	rep.CodigoCliFor		= doc.CodigoCliFor
			and	rep.NumeroDocumento		= doc.NumeroDocumento
			and	rep.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
			and	rep.CodigoRepresentante		between @RepresentanteInicial and @RepresentanteFinal)

	or	exists(select * from tbDoctoReceberRepresentante rep 
			where	rep.CodigoEmpresa		= doc.CodigoEmpresa
			and	rep.CodigoLocal			= doc.CodigoLocal
			and	rep.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
			and	rep.DataDocumento		= doc.DataDocumento
			and	rep.CodigoCliFor		= doc.CodigoCliFor
			and	rep.NumeroDocumento		= doc.NumeroDocumento
			and	rep.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
			and	rep.CodigoRepresentante		between @RepresentanteInicial and @RepresentanteFinal)
	)
	----------------------------------------------------------------------
	-- Devolucao das Vendas
	----------------------------------------------------------------------
	select 	 doc.CodigoEmpresa		as CodigoEmpresa
		,doc.CodigoLocal		as CodigoLocal
		,0 				as TipoTotalizacao
		,doc.DataDocumento		as DataDocumento
		,doc.NumeroDocumento		as NumeroDocumento
		,doc.CodigoCliFor		as CodigoCliFor
		,dft.CentroCusto		as CentroCusto
		,dft.CodigoPlanoPagamento	as CodigoPlanoPagamento
		,doc.ValorContabilDocumento 	as ValorContabilDocumento
		,dft.OrigemDocumentoFT		as OrigemDocumentoFT
		
		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'PEC') > 0
			then	'V'
			else	'F'
		end			as TipoPEC

		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'CLO') > 0
			then	'V'
			else	'F'
		end			as TipoCLO

		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'MOB') > 0
			then	'V'
			else	'F'
		end			as TipoMOB

		,case	when	dft.OrigemDocumentoFT = 'CV'
			then	'V'
			else	'F'
		end			as TipoVEC

		,case	when 	(select count(*) from tbItemDocumento itd 
				where	itd.CodigoEmpresa		= doc.CodigoEmpresa
				and	itd.CodigoLocal			= doc.CodigoLocal
				and	itd.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
				and	itd.DataDocumento		= doc.DataDocumento
				and	itd.CodigoCliFor		= doc.CodigoCliFor
				and	itd.NumeroDocumento		= doc.NumeroDocumento
				and	itd.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao
				and	itd.TipoRegistroItemDocto	= 'OUT') > 0
			then	'V'
			else	'F'
		end			as TipoOUT
		,(select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))

		 from	tbItemDocumento idoc 
		 inner 	join tbItemDocumentoFT idft 
		 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
		 and	idft.CodigoLocal		 = idoc.CodigoLocal
		 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
		 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
		 and	idft.DataDocumento		 = idoc.DataDocumento
		 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
		 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
		 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

		 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
		 and	idoc.CodigoLocal		 = doc.CodigoLocal
		 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
		 and	idoc.DataDocumento		 = doc.DataDocumento
		 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
		 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
		 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao) as ValorDesconto

		,case when @PEC = 'V' then
			 (select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'PEC'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorDescontoPeca

		,case when @CLO = 'V' then
			(select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))

			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento
	
			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'CLO'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end as ValorDescontoCLO
		
		,case when @MOB = 'V' then
			(select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))

			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and		idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento
	
			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'MOB'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end as ValorDescontoMOB

		,case when @VEC = 'V' then
			 (select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'VEC'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorDescontoVEC

		,case when @OUT = 'V' then
			 (select sum(coalesce((idoc.QtdeLancamentoItemDocto * idft.PrecoUnitarioOriginalItDocFT) - (idoc.ValorContabilItemDocto - idoc.ValorICMSSubstTribItemDocto),0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'OUT'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorDescontoOUT

		,case when @PEC = 'V' then
			 (select sum(coalesce(idoc.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'PEC'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilPeca

		,case when @CLO = 'V' then
			 (select sum(coalesce(idoc.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'CLO'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilCLO

		,case when @MOB = 'V' then
			 (select sum(coalesce(idoc.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'MOB'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilMOB

		,case when @VEC = 'V' then
			 (select sum(coalesce(idoc.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'VEC'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilVEC

		,case when @OUT = 'V' then
			 (select sum(coalesce(idoc.ValorContabilItemDocto,0))
			 from	tbItemDocumento idoc 
			 inner 	join tbItemDocumentoFT idft 
			 on	idft.CodigoEmpresa		 = idoc.CodigoEmpresa
			 and	idft.CodigoLocal		 = idoc.CodigoLocal
			 and	idft.EntradaSaidaDocumento	 = idoc.EntradaSaidaDocumento
			 and	idft.CodigoCliFor		 = idoc.CodigoCliFor
			 and	idft.DataDocumento		 = idoc.DataDocumento
			 and	idft.NumeroDocumento		 = idoc.NumeroDocumento
			 and	idft.TipoLancamentoMovimentacao  = idoc.TipoLancamentoMovimentacao
			 and	idft.SequenciaItemDocumento	 = idoc.SequenciaItemDocumento

			 where	idoc.CodigoEmpresa		 = doc.CodigoEmpresa
			 and	idoc.CodigoLocal		 = doc.CodigoLocal
			 and	idoc.EntradaSaidaDocumento	 = doc.EntradaSaidaDocumento
			 and	idoc.DataDocumento		 = doc.DataDocumento
			 and	idoc.CodigoCliFor		 = doc.CodigoCliFor
			 and	idoc.NumeroDocumento		 = doc.NumeroDocumento
			 and	idoc.TipoRegistroItemDocto  = 'OUT'
			 and	idoc.TipoLancamentoMovimentacao  = doc.TipoLancamentoMovimentacao)
			 else 0 
	     end  as ValorContabilOUT

	into	#tmpDevolucaoVendasDescontos

	from 	tbDocumento 			doc 

	inner	join tbDocumentoFT 		dft 
	on	dft.CodigoEmpresa		= doc.CodigoEmpresa
 	and	dft.CodigoLocal			= doc.CodigoLocal
 	and	dft.EntradaSaidaDocumento	= doc.EntradaSaidaDocumento
 	and	dft.DataDocumento		= doc.DataDocumento
 	and	dft.CodigoCliFor		= doc.CodigoCliFor
 	and	dft.NumeroDocumento		= doc.NumeroDocumento
	and	dft.TipoLancamentoMovimentacao  = 7
 	and	dft.CentroCusto			between @CCustoInicial and @CCustoFinal
 	and    ((dft.CodigoPlanoPagamento is null) or (dft.CodigoPlanoPagamento between @PlanoPagtoInicial and @PlanoPagtoFinal))

	inner join tbNaturezaOperacao natoper 
	on 	natoper.CodigoEmpresa 		= dft.CodigoEmpresa
	and 	natoper.CodigoNaturezaOperacao	= dft.CodigoNaturezaOperacao
	and	natoper.CodigoTipoOperacao	in (7, 8)	-- devolucao de venda
	and 	natoper.EntradaSaidaNaturezaOperacao = 'E'	-- devolucao de venda

	inner join tbRepresentantePedido reprped 
	on	reprped.CodigoEmpresa = doc.CodigoEmpresa
	and	reprped.CodigoLocal = doc.CodigoLocal
	and 	reprped.CentroCusto = dft.CentroCusto
	and 	reprped.NumeroPedido = doc.NumeroPedidoDocumento
	and	reprped.SequenciaPedido = doc.NumeroSequenciaPedidoDocumento
	and 	reprped.CodigoRepresentante	between @RepresentanteInicial and @RepresentanteFinal

 	-------------------------------------------- selecao dos parametros recebidos
 	where	doc.CodigoEmpresa		= @CodigoEmpresa
 	and	doc.CodigoLocal				= @CodigoLocal
 	and	doc.DataDocumento 			between @DataInicial 	and @DataFinal
 	and	doc.CodigoCliFor			between @ClienteInicial and @ClienteFinal
 	and	doc.EntradaSaidaDocumento	= 'E'
 	and	doc.CondicaoNFCancelada		= 'F'
 	and	doc.TipoLancamentoMovimentacao  in (7,11)

	update #tmpVendasDescontos				set ValorDesconto = 0 where ValorDesconto < 0
	update #tmpVendasDescontos				set ValorDescontoPeca = 0 where ValorDescontoPeca < 0
	update #tmpVendasDescontos				set ValorDescontoCLO = 0 where ValorDescontoCLO < 0
	update #tmpVendasDescontos				set ValorDescontoMOB = 0 where ValorDescontoMOB < 0
	update #tmpVendasDescontos				set ValorDescontoVEC = 0 where ValorDescontoVEC < 0
	update #tmpVendasDescontos				set ValorDescontoOUT = 0 where ValorDescontoOUT < 0

	update #tmpVendasDescontos				set ValorDescontoPeca = 0 where ValorDescontoPeca is null
	update #tmpVendasDescontos				set ValorDescontoCLO = 0 where ValorDescontoCLO is null
	update #tmpVendasDescontos				set ValorDescontoMOB = 0 where ValorDescontoMOB is null
	update #tmpVendasDescontos				set ValorDescontoVEC = 0 where ValorDescontoVEC is null
	update #tmpVendasDescontos				set ValorDescontoOUT = 0 where ValorDescontoOUT is null

	update #tmpVendasDescontos 				set ValorContabilPeca = 0 where ValorContabilPeca is null
	update #tmpVendasDescontos 				set ValorContabilCLO =  0 where ValorContabilCLO is null 
	update #tmpVendasDescontos 				set ValorContabilMOB =  0 where ValorContabilMOB is null
	update #tmpVendasDescontos 				set ValorContabilVEC =  0 where ValorContabilVEC is null
	update #tmpVendasDescontos 				set ValorContabilOUT =  0 where ValorContabilOUT is null

	update #tmpDevolucaoVendasDescontos 	set ValorDesconto = 0 where ValorDesconto < 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoPeca = 0 where ValorDescontoPeca < 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoCLO = 0 where ValorDescontoCLO < 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoMOB = 0 where ValorDescontoMOB < 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoVEC = 0 where ValorDescontoVEC < 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoOUT = 0 where ValorDescontoOUT < 0

	update #tmpDevolucaoVendasDescontos 	set ValorContabilDocumento = ValorContabilDocumento * -1 where ValorContabilDocumento <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorContabilPeca = ValorContabilPeca * -1 where ValorContabilPeca <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorContabilCLO = ValorContabilCLO * -1 where ValorContabilCLO <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorContabilMOB = ValorContabilMOB * -1 where ValorContabilMOB <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorContabilVEC = ValorContabilVEC * -1 where ValorContabilVEC <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorContabilOUT = ValorContabilOUT * -1 where ValorContabilOUT <> 0

	update #tmpDevolucaoVendasDescontos 	set ValorDesconto = ValorDesconto * -1 where ValorDesconto <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoPeca = ValorDescontoPeca * -1 where ValorDescontoPeca <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoCLO = ValorDescontoCLO * -1 where ValorDescontoCLO <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoMOB = ValorDescontoMOB * -1 where ValorDescontoMOB <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoVEC = ValorDescontoVEC * -1 where ValorDescontoVEC <> 0
	update #tmpDevolucaoVendasDescontos 	set ValorDescontoOUT = ValorDescontoOUT * -1 where ValorDescontoOUT <> 0

	insert into #tmpVendasDescontos select * from #tmpDevolucaoVendasDescontos

	----------------------------------------------------------------------
	-- Gera��o da tempor�ria que ser�o feitas as totaliza��es
	----------------------------------------------------------------------
	select	*
	into	#tmpFinal
	from	#tmpVendasDescontos 
	where 	1 = 2

	if @ComDesconto = 'V'
	begin
		insert into #tmpFinal
		select	*
		from	#tmpVendasDescontos 
		where	(  (@PEC = 'V' and TipoPEC = 'V')
			or (@CLO = 'V' and TipoCLO = 'V')
			or (@MOB = 'V' and TipoMOB = 'V')
			or (@VEC = 'V' and TipoVEC = 'V')
			or (@OUT = 'V' and TipoOUT = 'V'))
			and (ValorDesconto > 0 or ValorDesconto < 0)
	end

	if @SemDesconto = 'V'
	begin
		insert into #tmpFinal
		select	*
		from	#tmpVendasDescontos 
		where	(  (@PEC = 'V' and TipoPEC = 'V')
			or (@CLO = 'V' and TipoCLO = 'V')
			or (@MOB = 'V' and TipoMOB = 'V')
			or (@VEC = 'V' and TipoVEC = 'V')
			or (@OUT = 'V' and TipoOUT = 'V'))
			and (ValorDesconto = 0)
	end

	----------------------------------------------------------------------
	-- Totaliza��es por Centro de Custo
	----------------------------------------------------------------------
	insert	#tmpFinal
	select	doc.CodigoEmpresa	as CodigoEmpresa
		,doc.CodigoLocal		as CodigoLocal
		,1 						as TipoTotalizacao
		,'2099/12/31'			as DataDocumento
		,999999					as NumeroDocumento
		,99999999999999			as CodigoCliFor
		,doc.CentroCusto		as CentroCusto
		,null					as CodigoPlanoPagamento
		,sum(coalesce(doc.ValorContabilPeca+ doc.ValorContabilMOB + doc.ValorContabilVEC + doc.ValorContabilOUT,0))	as ValorContabilDocumento
		,null					as OrigemDocumentoFT
		,'X'					as TipoPEC
		,'X'					as TipoCLO
		,'X'					as TipoMOB
		,'X'					as TipoVEC
		,'X'					as TipoOUT
		,sum(coalesce(doc.ValorDescontoPeca + doc.ValorDescontoCLO + doc.ValorDescontoMOB + doc.ValorDescontoVEC + doc.ValorDescontoOUT,0)) as ValorDesconto
		,sum(coalesce(doc.ValorDescontoPeca,0)) as ValorDescontoPeca
		,sum(coalesce(doc.ValorDescontoCLO,0)) as ValorDescontoCLO
		,sum(coalesce(doc.ValorDescontoMOB,0)) as ValorDescontoMOB
		,sum(coalesce(doc.ValorDescontoVEC,0)) as ValorDescontoVEC
		,sum(coalesce(doc.ValorDescontoOUT,0)) as ValorDescontoOUT
		,sum(coalesce(doc.ValorContabilPeca,0))	as ValorContabilPeca
		,sum(coalesce(doc.ValorContabilMOB,0))	as ValorContabilMOB
		,sum(coalesce(doc.ValorContabilCLO,0))	as ValorContabilCLO
		,sum(coalesce(doc.ValorContabilVEC,0))	as ValorContabilVEC
		,sum(coalesce(doc.ValorContabilOUT,0))	as ValorContabilOUT


	from 	#tmpFinal doc 
	where	TipoTotalizacao = 0
	group	by doc.CodigoEmpresa
		,doc.CodigoLocal
		,doc.CentroCusto
	order	by doc.CodigoEmpresa
		,doc.CodigoLocal
		,doc.CentroCusto

	----------------------------------------------------------------------
	-- Totaliza��es por Plano de Pagamento
	----------------------------------------------------------------------

	insert	#tmpFinal

	select	doc.CodigoEmpresa		as CodigoEmpresa
		,doc.CodigoLocal			as CodigoLocal
		,2 							as TipoTotalizacao
		,'2099/12/31'				as DataDocumento
		,999999						as NumeroDocumento
		,99999999999999				as CodigoCliFor
		,99999999					as CentroCusto
		,doc.CodigoPlanoPagamento	as CodigoPlanoPagamento
		,sum(coalesce(doc.ValorContabilPeca+ doc.ValorContabilMOB + doc.ValorContabilVEC + doc.ValorContabilOUT,0))	as ValorContabilDocumento
		,null					as OrigemDocumentoFT
		,'X'					as TipoPEC
		,'X'					as TipoCLO
		,'X'					as TipoMOB
		,'X'					as TipoVEC
		,'X'					as TipoOUT
		,sum(coalesce(doc.ValorDescontoPeca + doc.ValorDescontoCLO + doc.ValorDescontoMOB + doc.ValorDescontoVEC + doc.ValorDescontoOUT,0)) as ValorDesconto		,sum(doc.ValorDescontoPeca) as ValorDescontoPeca
		,sum(coalesce(doc.ValorDescontoCLO,0)) as ValorDescontoCLO
		,sum(coalesce(doc.ValorDescontoMOB,0)) as ValorDescontoMOB
		,sum(coalesce(doc.ValorDescontoVEC,0)) as ValorDescontoVEC
		,sum(coalesce(doc.ValorDescontoOUT,0)) as ValorDescontoOUT
		,sum(coalesce(doc.ValorContabilPeca,0))	as ValorContabilPeca
		,sum(coalesce(doc.ValorContabilMOB,0))	as ValorContabilMOB
		,sum(coalesce(doc.ValorContabilCLO,0))	as ValorContabilCLO
		,sum(coalesce(doc.ValorContabilVEC,0))	as ValorContabilVEC
		,sum(coalesce(doc.ValorContabilOUT,0))	as ValorContabilOUT

	from 	#tmpFinal doc 

	where	TipoTotalizacao = 0

	group	by doc.CodigoEmpresa
		,doc.CodigoLocal
		,doc.CodigoPlanoPagamento

	order	by doc.CodigoEmpresa
		,doc.CodigoLocal
		,doc.CodigoPlanoPagamento


	----------------------------------------------------------------------
	-- retorno dos dados conforme parametros de tipo/desconto.
	----------------------------------------------------------------------
	select	 doc.CodigoEmpresa
		,doc.CodigoLocal
		,doc.TipoTotalizacao
		,doc.DataDocumento
		,doc.NumeroDocumento
		,doc.CodigoCliFor
		,cli.NomeCliFor
		,doc.CentroCusto
		,ccu.DescricaoCentroCusto
		,isnull(doc.CodigoPlanoPagamento,'----') 		as CodigoPlanoPagamento
		,isnull(ppg.DescricaoPlanoPagamento,'VENDA DE VE�CULO') as DescricaoPlanoPagamento
		,convert(numeric(12,2),(doc.ValorContabilPeca + doc.ValorContabilMOB + doc.ValorContabilCLO + doc.ValorContabilVEC + doc.ValorContabilOUT))	as ValorContabilDocumento
		,doc.TipoPEC
		,doc.TipoCLO
		,doc.TipoMOB
		,doc.TipoVEC
		,doc.TipoOUT
		,convert(numeric(12,2),(doc.ValorDescontoPeca + doc.ValorDescontoCLO + doc.ValorDescontoMOB + doc.ValorDescontoVEC + doc.ValorDescontoOUT))		as ValorDesconto


		,doc.OrigemDocumentoFT

		,
		case 	when doc.TipoTotalizacao = 0 then 
							case when doc.ValorContabilDocumento = 0
							then 0
							else convert(numeric(12,2),((doc.ValorDescontoPeca + doc.ValorDescontoCLO + doc.ValorDescontoMOB + doc.ValorDescontoVEC + doc.ValorDescontoOUT  ) / (doc.ValorContabilPeca + ValorContabilMOB + ValorContabilCLO + ValorContabilVEC + ValorContabilOUT + doc.ValorDescontoPeca + doc.ValorDescontoCLO + doc.ValorDescontoMOB + doc.ValorDescontoVEC + doc.ValorDescontoOUT  ) * 100))
							end
			when doc.TipoTotalizacao <> 0 then 0
		end as PercDesc
		,convert(numeric(12,2),doc.ValorDescontoPeca)		as ValorDescontoPeca
		,convert(numeric(12,2),doc.ValorDescontoCLO)		as ValorDescontoCLO
		,convert(numeric(12,2),doc.ValorDescontoMOB)		as ValorDescontoMOB
		,convert(numeric(12,2),doc.ValorDescontoVEC)		as ValorDescontoVEC
		,convert(numeric(12,2),doc.ValorDescontoOUT)		as ValorDescontoOUT
		,convert(numeric(12,2),doc.ValorContabilPeca)   	as ValorContabilPeca
		,convert(numeric(12,2),doc.ValorContabilMOB)    	as ValorContabilMOB
		,convert(numeric(12,2),doc.ValorContabilCLO)    	as ValorContabilCLO
		,convert(numeric(12,2),doc.ValorContabilVEC)    	as ValorContabilVEC
		,convert(numeric(12,2),doc.ValorContabilOUT)    	as ValorContabilOUT

	from	#tmpFinal doc
	
	left	join tbCentroCusto ccu 
	on	ccu.CodigoEmpresa	= doc.CodigoEmpresa
	and	ccu.CentroCusto		= doc.CentroCusto

	left	join tbPlanoPagamento ppg 
	on	ppg.CodigoEmpresa	 = doc.CodigoEmpresa
	and	ppg.CodigoPlanoPagamento = doc.CodigoPlanoPagamento

	left	join tbCliFor cli 
	on	cli.CodigoEmpresa	 = doc.CodigoEmpresa
	and	cli.CodigoCliFor	 = doc.CodigoCliFor

	where (    (@SomenteClientePrimeiraCompra = 'F')
			or (@SomenteClientePrimeiraCompra = 'V' 
				and ((select count(CodigoCliFor) from tbDocumento
							where	tbDocumento.CodigoEmpresa		= doc.CodigoEmpresa
 								and	tbDocumento.CodigoLocal			= doc.CodigoLocal
 								and	tbDocumento.DataDocumento 		between @DataInicial 	and @DataFinal
 								and	tbDocumento.CodigoCliFor		= doc.CodigoCliFor
 								and	tbDocumento.EntradaSaidaDocumento	= 'S'
 								and	tbDocumento.CondicaoNFCancelada		= 'F'
 								and	tbDocumento.TipoLancamentoMovimentacao  in (7,11)) = 1 ))
			)

	order	by	doc.CodigoEmpresa,
				doc.CodigoLocal,
				doc.TipoTotalizacao,
				doc.CentroCusto,
				doc.DataDocumento,
				doc.NumeroDocumento


SET NOCOUNT OFF

GO
---------------------------------------------------------------------------------- fim da proc
grant exec on dbo.whRelFTVendasDescontos to SQLUsers
GO